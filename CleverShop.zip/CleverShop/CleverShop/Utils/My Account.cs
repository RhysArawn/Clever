﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Support.UI;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;



namespace CleverShop.Utils
{
    class MyAccount
    {
        public StringBuilder verificationErrors;
        public void EShop_AccountPage
        (IWebDriver driver)

        {
            driver.FindElement(By.XPath("//form[@id='logoutForm']/section")).Click();
            driver.FindElement(By.XPath("//form[@id='logoutForm']/section[2]/a[2]/div")).Click();
            Thread.Sleep(2000);
            try
            {
                Assert.AreEqual("Profile", driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[1]/following::h4[1]")).Text);
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            try
            {
                Assert.AreEqual("Username", driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[2]/following::label[1]")).Text);
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            try
            {
                Assert.AreEqual("Phone number", driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Send verification email'])[1]/following::label[1]")).Text);
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            try
            {
                Assert.AreEqual("demouser@microsoft.com", driver.FindElement(By.Id("Username")).GetAttribute("value"));
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            try
            {
                Assert.AreEqual("demouser@microsoft.com", driver.FindElement(By.Id("Email")).GetAttribute("value"));
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            
        }
    }



    }

    

