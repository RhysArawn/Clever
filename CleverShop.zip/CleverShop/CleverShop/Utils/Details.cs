﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleverShop.Utils
{
    public class Details
    {

        ///Hack File, Place to store things before changing them to perm config 
        ///
        public class Config
        {

            
          
            public static string BaseUrl = "https://eshoponwebclever.azurewebsites.net/";
            public static string Username = "demouser@microsoft.com";
            public static string Password = "Pass@word1";
            public static string URLS;
          
        }

    }
}
