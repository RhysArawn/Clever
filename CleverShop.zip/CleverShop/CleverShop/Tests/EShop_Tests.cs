﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;
using OpenQA.Selenium.DevTools.V104.Memory;
using System.Net.Http.Headers;

namespace CleverShop
{

    public class EShop_Tests
    {

        public IWebDriver driver;
        public StringBuilder verificationErrors;
        public bool acceptNextAlert = true;
        public string title = "div.navAreaTitle > span";

        public void Eshop_Test_Forward(IWebDriver driver)
        //Users can page forward and back through the product catalogue 
        {


            Utils.EShop Eshop = new Utils.EShop(); //Setting up , Yes we can do it differently. but this is a quick way.
            //Press Foward
            Eshop.EShop_Forward(driver);
            //Assert that you gone Page forward
            //setting the Validation Text here
            Eshop.ValidationText = "Showing 2 of 12 products - Page 2 - 2";
            //Assert Text Top of the page
            Eshop.Eshop_ShowingProductsAssertTop(driver);
            //Assert Text Bottom of the page
            Eshop.Eshop_ShowingProductsAssertBottom(driver);
        }
        public void Eshop_Test_Forward_Then_Back(IWebDriver driver)
        //Users can page forward and back through the product catalogue 
        {
            Utils.EShop Eshop = new Utils.EShop(); //Setting up , Yes we can do it differently. but this is a quick way.
            //Press Foward
            Eshop.EShop_Forward(driver);
            //Assert that you gone Page forward
            Eshop.ValidationText = "Showing 2 of 12 products - Page 2 - 2";
            //Assert Text Top of the Page
            Eshop.Eshop_ShowingProductsAssertTop(driver);
            //Assert Text Bottom of the Page
            Eshop.Eshop_ShowingProductsAssertBottom(driver);
            //Click on Back
            Eshop.EShop_Back(driver);
            Thread.Sleep(1000);
            Eshop.ValidationText = "Showing 10 of 12 products - Page 1 - 2";
            //Assert Text Top of Page
            Eshop.Eshop_ShowingProductsAssertTop(driver);
            //Assert Text Bottom of Page
            Eshop.Eshop_ShowingProductsAssertBottom(driver);


        }
        public void Eshop_Test_Filter_Catalogue_Items_Type(IWebDriver driver)
        //Users can Filter item Type
        {
            Utils.EShop Eshop = new Utils.EShop(); //Setting up , Yes we can do it differently. but this is a quick way.
            //I want to filter on a Type Mug , Ya mug :P
            Eshop.type = "Mug";
            //Click on Type Dropdown then Click filter
            Eshop.EShop_Type(driver);
            Thread.Sleep(2000);
            //Setting up Assert Text so we can make it changeable.
            Eshop.ValidationText = ".NET BLACK & WHITE MUG";
            //This will Check the first item on that list.
            Eshop.Eshop_FilterAssertFirstItem(driver);
        }
        public void Eshop_Test_AddItemToBasket(IWebDriver driver)
        //Users can Add things to the basket
        {
            Utils.EShop Eshop = new Utils.EShop();
            Utils.EBasket Ebasket = new Utils.EBasket();//Setting up , Yes we can do it differently. but this is a quick way.
            // Stating which shop item you want by number 
            Eshop.ShopItemNumber = "2";
            // Add that Shop item to the basket.
            Eshop.EShop_AddItem_Xpath(driver);
            //verify that we gone to the basket 
            //Setting item as 1
            Ebasket.EBasketQuantity = "1";
            //Setting Assert Quantity
            Ebasket.EBasket_QUANTITY_Assert(driver);
            //Product name Check
            Ebasket.EBasketName = ".NET Black & White Mug";
            Ebasket.EBasket_ProductName_Assert(driver);
            Ebasket.Ebasket_URLASSERT(driver);

        }
        public void Eshop_Test_LoginGoToDetails(IWebDriver driver)
        //users can go to Login Page, go to account details
        {
            Utils.Login login = new Utils.Login();
            Utils.MyAccount myAccount = new Utils.MyAccount();       
            login.EShop_Login(driver);
            myAccount.EShop_AccountPage(driver);
            

        }
        public void Eshop_Test_CheckoutItem_CheckOrder(IWebDriver driver)
        //Users can select an item, checkout their order and view details of that order on the my orders page 
        {
            Utils.Login login = new Utils.Login();
            Utils.EShop Eshop = new Utils.EShop();
            Utils.EBasket Ebasket = new Utils.EBasket();
            Utils.Orders order = new Utils.Orders();
            Eshop.ShopItemNumber = "2";
            //Add the shop item
            Eshop.EShop_AddItem_Xpath(driver);
            //Checkout that shop item
            Ebasket.Ebasket_CheckoutButton(driver);
            // Login in so you can pay for it
            login.EShop_Login(driver);
            //Go back to the basket
            Eshop.EshopOrdersBasket(driver);
            //Click on Checkout button Again
            Ebasket.Ebasket_CheckoutButton(driver);
            //Click on Pay now
            Ebasket.Ebasket_PayNow(driver);
            //Go to my order page
            order.Orders_MyOrders(driver);
            // making this dumb. Pass id 
            order.ordernumber = "85";
            order.FindMyOrder(driver);
            //Validation check that we made it to the page. making this dumb.
            order.OrdersValidation(driver);

        }
        }
}




