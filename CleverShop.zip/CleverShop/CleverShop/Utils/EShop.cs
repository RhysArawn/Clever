﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Support.UI;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;



namespace CleverShop.Utils
{
    class EShop
    {

        public StringBuilder verificationErrors;
        public bool acceptNextAlert = true;
        public string Brand;
        public string type;
        public string name;
        public string description;
        public string ShopItemNumber;
        public string ValidationText;
       

      
       
        
        public void EShop_Brand(IWebDriver driver)
        {
            driver.FindElement(By.Id("CatalogModel_BrandFilterApplied")).Click();
            Thread.Sleep(2000);
            new SelectElement(driver.FindElement(By.Id("CatalogModel_BrandFilterApplied"))).SelectByText(Brand);
            driver.FindElement(By.CssSelector("input.esh-catalog-send")).Click();
        }

        public void EShop_Type(IWebDriver driver)
        {
            driver.FindElement(By.Id("CatalogModel_TypesFilterApplied")).Click();
            Thread.Sleep(2000);
            new SelectElement(driver.FindElement(By.Id("CatalogModel_TypesFilterApplied"))).SelectByText(type);
            driver.FindElement(By.CssSelector("input.esh-catalog-send")).Click();
        }
        public void EShop_Forward(IWebDriver driver)
        {
            driver.FindElement(By.Id("Next")).Click();
        }
        public void EShop_Back(IWebDriver driver)
        {
            driver.FindElement(By.Id("Previous")).Click();
        }
        public void EShop_AddItem_Xpath(IWebDriver driver)
            /// No element ID's Passed first one, Ew.
        {
            if (ShopItemNumber == "1")
                driver.FindElement(By.XPath("//input[@value='[ ADD TO BASKET ]'])["+ ShopItemNumber + "]")).Click();
            else
            {
                driver.FindElement(By.XPath("//div["+ ShopItemNumber + "]/form/input")).Click();
            }
        }
        public void EShop_AddItem_CSS(IWebDriver driver)
        /// No element ID's Passed first one, Ew.
        {
            if (ShopItemNumber=="1" )
            driver.FindElement(By.CssSelector("body > div > div > div.esh-catalog-items.row > div:nth-child(1) > form > input.esh-catalog-button")).Click();
            else
            {
                driver.FindElement(By.CssSelector("body > div > div > div.esh - catalog - items.row > div:nth - child("+ ShopItemNumber + ") > form > input.esh - catalog - button")).Click();
            }
                                              
        }
       public void Eshop_ShowingProductsAssertBottom(IWebDriver driver)
        {
            Assert.AreEqual(ValidationText, driver.FindElement(By.XPath("//div[3]/div/article/nav/div[2]/span")).Text);
        }
        public void Eshop_ShowingProductsAssertTop(IWebDriver driver)
        {
            Assert.AreEqual(ValidationText, driver.FindElement(By.CssSelector("span.esh-pager-item")).Text);
        }
        public void Eshop_FilterAssertFirstItem(IWebDriver driver)
        {/// Yeah i know this is a cheap trick :)

            Assert.AreEqual(ValidationText, driver.FindElement(By.CssSelector("div.esh-catalog-name > span")).Text);
        }
        public void EshopOrdersBasket(IWebDriver driver)
        {
            driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Log Out'])[1]/following::div[2]")).Click();
        }
    }
}

    

