﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Support.UI;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;



namespace CleverShop.Utils
{
    class Login
    {
        public StringBuilder verificationErrors;
        public void EShop_Login(IWebDriver driver)

        {
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//div/a")).Click();
            Thread.Sleep(2000);
            driver.FindElement(By.Id("Input_Email")).Click();
            driver.FindElement(By.Id("Input_Email")).Clear();
            driver.FindElement(By.Id("Input_Email")).SendKeys(Details.Config.Username);
            
            driver.FindElement(By.Id("Input_Password")).Click();
            driver.FindElement(By.Id("Input_Password")).Clear();
            driver.FindElement(By.Id("Input_Password")).SendKeys(Details.Config.Password);
            driver.FindElement(By.XPath("//button[@type='submit']")).Click();
        }
    }
}
    

