using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;
using CleverShop.Utils;
using CleverShop;

namespace CleverShop.Browsers
{
    [TestClass]
    public class Test_ELCChrome
    {
        //Chrome Automated Tests 
        public IWebDriver driver;
        public StringBuilder verificationErrors;



        [TestInitialize]
        public void TestInitialize()
        {
            try
            {

                driver = new ChromeDriver();
                string URL = Details.Config.BaseUrl;


                driver.Manage().Window.Maximize();
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
                driver.Navigate().GoToUrl(URL);

                Thread.Sleep(3400);

            }
            catch
            {
                driver.Quit();
            }
        }

        [TestMethod]
        public void EShop_Test_ForwardButton()

        {

            EShop_Tests eShop_Tests = new EShop_Tests();
            eShop_Tests.Eshop_Test_Forward(driver);

        }
        [TestMethod]
        public void Eshop_Test_BackButton_Chrome()

        {

            EShop_Tests eShop_Tests = new EShop_Tests();
            eShop_Tests.Eshop_Test_Forward_Then_Back(driver);

        }
        [TestMethod]
        public void Eshop_Test_FilterCatalogueItemTypes_Chrome()

        {

            EShop_Tests eShop_Tests = new EShop_Tests();
            eShop_Tests.Eshop_Test_Filter_Catalogue_Items_Type(driver);

        }
        [TestMethod]
        public void Eshop_Test_AdditemBasket_Chrome()

        {

            EShop_Tests eShop_Tests = new EShop_Tests();
            eShop_Tests.Eshop_Test_AddItemToBasket(driver);

        }
        [TestMethod]
        public void Eshop_Test_LoginThenGoToDetails_Chrome()

        {

            EShop_Tests eShop_Tests = new EShop_Tests();
            eShop_Tests.Eshop_Test_LoginGoToDetails(driver);

        }
        [TestMethod]
        public void Eshop_Test_CheckoutitemThenCheckOrder_Chrome()

        {

            EShop_Tests eShop_Tests = new EShop_Tests();
            eShop_Tests.Eshop_Test_CheckoutItem_CheckOrder(driver);

        }

        [TestCleanup]
        public void TeardownTest() => driver.Quit();
    }
}