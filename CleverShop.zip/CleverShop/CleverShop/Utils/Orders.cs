﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Support.UI;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;



namespace CleverShop.Utils
{
    class Orders
    {
        public string ordernumber;
        public StringBuilder verificationErrors;
        public void Orders_MyOrders(IWebDriver driver)

        {
            driver.FindElement(By.XPath("//form[@id='logoutForm']/section[2]/a/div")).Click();

        }
        public void FindMyOrder(IWebDriver driver)
        {
            driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Pending'])["+ ordernumber + "]/following::a[1]")).Click();
        }
        public void OrdersValidation(IWebDriver driver)
        {
            //Assert.AreEqual("TOTAL", driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='$ 17.00'])[1]/following::section[3]")).Text);
            Assert.AreEqual("Order Detail - Microsoft.eShopOnWeb", driver.Title);
        }
    }
}
    

