﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Support.UI;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace CleverShop.Utils
{
    class EBasket
    {
        public string EBasketQuantity;
        public string EBasketName;

        public void EBasket_QUANTITY_Assert(IWebDriver driver)
        //Validation Assert 
        {
            Assert.AreEqual(EBasketQuantity, driver.FindElement(By.Name("Items[0].Quantity")).GetAttribute("value"));

        }
        public void EBasket_UPDATE_Assert(IWebDriver driver)
        /// No element ID's Passed first one, Ew.
        {
            Assert.AreEqual("[ Update ]", driver.FindElement(By.Name("updatebutton")).Text);

        }
        public void EBasket_Checkout_Assert(IWebDriver driver)
        /// No element ID's Passed first one, Ew.
        {
            Assert.AreEqual("[ Checkout ]", driver.FindElement(By.LinkText("[ Checkout ]")).Text);

        }
        public void EBasket_ContinueShopping_Assert(IWebDriver driver)
        /// No element ID's Passed first one, Ew.
        {
            Assert.AreEqual("[ Continue Shopping ]", driver.FindElement(By.LinkText("[ Continue Shopping ]")).Text);

        }
        public void EBasket_ProductName_Assert(IWebDriver driver)
        /// No element ID's Passed first one, Ew.
        {
            Assert.AreEqual(EBasketName, driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Cost'])[1]/following::section[2]")).Text);

        }

        public void Ebasket_CheckoutButton(IWebDriver driver)
        {
            driver.FindElement(By.XPath("//a[contains(text(),'[ Checkout ]')]")).Click();
        }
        public void Ebasket_URLASSERT(IWebDriver driver)
        {
            string url = driver.Url;
            Console.WriteLine(url);
            Assert.AreEqual(url, "https://eshoponwebclever.azurewebsites.net/Basket");
        }
        public void Ebasket_PayNow(IWebDriver driver)
        {
            driver.FindElement(By.XPath("//input[@value='[ Pay Now ]']")).Click();
        }
    }
}
    

